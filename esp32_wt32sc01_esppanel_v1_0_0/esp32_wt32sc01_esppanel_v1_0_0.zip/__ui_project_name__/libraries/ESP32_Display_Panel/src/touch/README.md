# Touch Controllers

|                                        **Name**                                        | **Version** |
| -------------------------------------------------------------------------------------- | ----------- |
| [esp_lcd_touch](https://components.espressif.com/components/espressif/esp_lcd_touch)   | 1.1.1       |
| [CST816S](https://components.espressif.com/components/espressif/esp_lcd_touch_cst816s) | 1.0.3       |
| [FT5x06](https://components.espressif.com/components/espressif/esp_lcd_touch_ft5x06)   | 1.0.6       |
| [GT911](https://components.espressif.com/components/espressif/esp_lcd_touch_gt911)     | 1.1.0       |
| [GT1151](https://components.espressif.com/components/espressif/esp_lcd_touch_gt1151)   | 1.0.5~1     |
| ST1633                                                                                 | 0.1.0       |
| [ST7123](https://components.espressif.com/components/espressif/esp_lcd_touch_st7123)   | 0.0.1       |
| [TT21100](https://components.espressif.com/components/espressif/esp_lcd_touch_tt21100) | 1.1.0       |
| [XPT2046](https://components.espressif.com/components/atanisoft/esp_lcd_touch_xpt2046) | 1.0.4       |
